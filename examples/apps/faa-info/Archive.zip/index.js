'use strict';

module.change_code = 1;

var _ = require('lodash');

var Alexa = require('alexa-app');

var app = new Alexa.app('airportinfo');

var FAADataHelper = require('./faa_data_helper');

app.launch(function(req, res){ //this method get triggered when skill is invoked 
    var prompt = 'For delay information, tell me an Airport code.';
    
    res.say(prompt).reprompt(prompt).shouldEndSession(false); //reprompt when to expect response from user
    														  //shouldEndSession stays open to recieve user message 
    
    
    
});

app.intent('airportinfo', {
	'slots' : {
		'AIRPORTCODE' : 'FAACODES'

	},

	'utterances': ['{|flight|airport} {|delay|status} {|info} {|for} {-|AIRPORTCODE}']

	},

		function(req, res) {
			// get the slot

			var airportCode = req.slot('AIRPORTCODE');

			var reprompt = 'Tell me an airport code to get the delay information.';

		if (_.isEmpty(airportCode)) {
			var prompt = 'I didn\'t hear an aiport code. Tell me an airport code.';

			res.say(prompt).reprompt(reprompt).shouldEndSession(false);

			return true;

		} else {

			var faaHelper = new FAADataHelper();

		faaHelper.requestAirportStatus(airportCode).then(function(airportStatus) {
			console.log(airportStatus);

			res.say(faaHelper.formatAirportStatus(airportStatus)).send();



		}).catch(function(err){
			console.log(err.statusCode);

			var prompt = 'I didn\'t have data for an airport code of ' + airportCode;

			res.say(prompt).reprompt(reprompt).shouldEndSession(false).send();


		});
				return false;

		}






		}





);






module.exports = app; 